import Vue from "vue";
import Vuex from "vuex";
import axios from 'axios';
// import { uuid } from "uuidv4";
Vue.use(Vuex);
const store = new Vuex.Store({
  state: {
    //Список продуктів   ( Читання: Крок 1 - описали дані
    productsListData: [],
  },
  mutations: {
    setProductsListData(state, data) {
      state.productsListData = [...data];
    },
  },
  actions: {
    loadData({ commit }) {
        axios.get('http://localhost:3000/products/list')
        .then(res=>res.data)
        .then(resData=>{
            commit('productsListData', resData)
        })
        .catch(err)
    //   const db = firebase.firestore();
    //   db.collection("productsListData")
    //     .get()
    //     .then((snap) => {
    //       const productsListData = [];
    //       snap.forEach((doc) => {
    //         productsListData.push({ id: doc.id, ...doc.data() });
    //       });
    //       commit("setProductsListData", productsListData);
    //     });
    },
  },
  //Зчитуємо дані зі стора (state)
  getters: {
    // Читання Крок 2) Створюємо функцію, яка повертає потрібні дані
    getProductsListData: (state) => {
      
      return state.productsListData;
    },
  },
});
export default store;